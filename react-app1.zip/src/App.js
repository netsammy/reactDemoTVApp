import logo from './logo.svg';
import './App.css';
import MathOperations from './MathOperations';
import Calculator from './Calculator';

function App() {
  return (
    <div className="App">
      <Calculator/>
      
    </div>
  );
}

export default App;
